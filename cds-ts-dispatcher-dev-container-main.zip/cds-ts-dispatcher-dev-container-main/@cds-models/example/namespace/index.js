// This is an automatically generated file. Please do not change its contents manually!
const cds = require('@sap/cds')
const csn = cds.entities('example.namespace')
module.exports.Entity1 = csn.Entity1
module.exports.Entity1_ = csn.Entity1
module.exports.Entity2 = csn.Entity2
module.exports.Entity2_ = csn.Entity2
// events
// actions
// enums
