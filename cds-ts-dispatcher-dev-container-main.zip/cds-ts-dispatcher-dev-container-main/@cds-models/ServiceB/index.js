// This is an automatically generated file. Please do not change its contents manually!
const cds = require('@sap/cds')
const csn = cds.entities('ServiceB')
module.exports = { name: 'ServiceB' }
module.exports.Entity2 = csn.Entity2
module.exports.Entity2_ = csn.Entity2
// events
// actions
// enums
