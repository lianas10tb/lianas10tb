// This is an automatically generated file. Please do not change its contents manually!
const cds = require('@sap/cds')
const csn = cds.entities('sap.common')
module.exports.Language = csn.Languages
module.exports.Languages = csn.Languages
module.exports.Country = csn.Countries
module.exports.Countries = csn.Countries
module.exports.Currency = csn.Currencies
module.exports.Currencies = csn.Currencies
module.exports.Timezone = csn.Timezones
module.exports.Timezones = csn.Timezones
// events
// actions
// enums
