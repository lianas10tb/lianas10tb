// This is an automatically generated file. Please do not change its contents manually!
const cds = require('@sap/cds')
const csn = cds.entities('ServiceA')
module.exports = { name: 'ServiceA' }
module.exports.Entity1 = csn.Entity1
module.exports.Entity1_ = csn.Entity1
// events
// actions
// enums
