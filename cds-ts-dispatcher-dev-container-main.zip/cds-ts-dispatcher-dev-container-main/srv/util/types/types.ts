// Example
export type AType = string;
