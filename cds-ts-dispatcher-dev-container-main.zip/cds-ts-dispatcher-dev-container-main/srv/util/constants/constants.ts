const Constants = {
  // Example
  CONSTANT_1: {
    PROP_CONSTANT_1: 'SOMETHING',
  },
};

export default Constants;
