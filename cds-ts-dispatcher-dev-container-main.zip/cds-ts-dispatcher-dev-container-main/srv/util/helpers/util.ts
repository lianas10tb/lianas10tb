const Util = {
  // Example
  aHelperFunction() {
    return 1;
  },
};

export default Util;
